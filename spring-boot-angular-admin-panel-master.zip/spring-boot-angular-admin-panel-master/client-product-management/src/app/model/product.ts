export class Product {
  id: number;
  name: string = "";
  price: number = 0;
  explanation: string = "";
}
